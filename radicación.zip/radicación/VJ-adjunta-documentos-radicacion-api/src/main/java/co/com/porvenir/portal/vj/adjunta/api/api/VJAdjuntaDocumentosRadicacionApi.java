package co.com.porvenir.portal.vj.adjunta.api.api;

import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONObject;

import java.io.InputStream;

import javax.portlet.PortletRequest;

/**
 * @author POR09646
 */
public interface VJAdjuntaDocumentosRadicacionApi {
	public JSONObject cargarDocumento(PortletRequest request, boolean esPdf, String idDocumento, String idBeneficiario,
			JSONArray imagenesBase64);

	public JSONObject eliminarDocumento(PortletRequest request, String idDocumento, String idBeneficiario);

	public InputStream descargarDocumento(PortletRequest request, String idDocumento, String idBeneficiario);

	public InputStream descargaDocumentoOnBase(PortletRequest request, String idDocumento, String idBeneficiario);

	public InputStream generarDocumentoAsOutputStream(PortletRequest request, String idDocumento);

	public String generarDocumentoAsBase64(PortletRequest request, String idDocumento);

	public JSONObject consultarListaDocumentos(PortletRequest request);

	public JSONObject guardarAdjunta(PortletRequest request);

	public JSONObject guardarFirma(PortletRequest request);

	/**
	 * Funcion para obtener los parametros del cargue documental, segun la
	 * solicitud.
	 * 
	 * @param idSolicitud
	 * @return
	 */
	public JSONObject getParametrosDocumentos(String idSolicitud);

	/**
	 * Funcion para descargar documentos consultando onbase para adjunta 2
	 * radicacion
	 * 
	 * @param request
	 * @param idDocumento
	 * @param idBeneficiario
	 * @return
	 */
	public JSONObject descargarDocumentoAdjunta2(PortletRequest request, String idDocumento, String idBeneficiario);

	/**
	 * Funcion para obtener el valor de un parametro del request
	 * 
	 * @param request
	 * @param nombreParametro
	 * @return {@link String}
	 */
	public String inicializaParametro(PortletRequest request, String nombreParametro);

}