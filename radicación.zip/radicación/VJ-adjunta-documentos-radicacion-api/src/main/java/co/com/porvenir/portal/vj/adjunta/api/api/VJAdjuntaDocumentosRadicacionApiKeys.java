
package co.com.porvenir.portal.vj.adjunta.api.api;

public class VJAdjuntaDocumentosRadicacionApiKeys {

	private VJAdjuntaDocumentosRadicacionApiKeys() {
		super();
	}

	public static final String CODIGO = "codigo";

	public static final String LISTA_DOCUMENTOS = "listaDocumentos";

	public static final String CODIGO_DIGITALIZACION = "codigoDigitalizacion";
	public static final String DOCUMENTO_ID = "documentoId";
	public static final String DOCUMENTO = "documento";
	public static final String ESTADO_DOCUMENTO = "estadoDocumento";
	public static final String NOMBRE_DOCUMENTO = "nombreDocumento";
	public static final String NOMBRE_RECHAZO = "nombreRechazoDocumento";
	public static final String REQUIERE_FIRMA = "requiereFirmaElectronica";
	public static final String ESTA_FIRMADO = "firmado";

	public static final String DOCUMENTOS = "documentos";

	public static final String ID_BENEFICIO = "idBeneficio";
	public static final String PASO_TRANSACCION = "pasoTransaccion";
	public static final String ACTIVIDAD_BPM = "actividadBpm";

	// Url - lista propiedades
	public static final String URL_REST_BTN_VOLVER_RADICACION_P1 = "URL_REST_BTN_VOLVER_RADICACION_P1";
	public static final String URL_REST_VJ_GUARDAR_CARGA_DOCUMENTAL_RADICACION = "URL_REST_VJ_GUARDAR_CARGA_DOCUMENTAL_RADICACION";
	public static final String URL_REST_DESCARGAR_DOCUMENTOS_RADICACION = "URL_REST_VJ_DESCARGAR_DOCUMENTOS_VALIDACION_DOCUMENTAL";
	public static final String URL_REST_ELIMINAR_DOCUMENTO_RADICACION = "URL_REST_ELIMINAR_DOCUMENTO_RADICACION";
	public static final String URL_REST_FIRMA_ELECTRONICA_RADICACION = "URL_REST_FIRMA_ELECTRONICA_RADICACION";
	public static final String URL_REST_BTN_VOLVER_FIRMA_RADICACION = "URL_REST_BTN_VOLVER_FIRMA_RADICACION";
	public static final String URL_REST_VJ_CARGA_DOCUMENTAL_RADICACION = "URL_REST_VJ_CARGA_DOCUMENTAL_RADICACION";
	public static final String URL_REST_CONSULTA_FORMATO_HL = "URL_REST_CONSULTA_FORMATO_HL";
	public static final String URL_REST_CONSULTAR__LISTA_DOCUMENTOS_RADICACION = "URL_REST_CONSULTA_DOCUMENTOS_RADICACION";
	public static final String URL_REST_BTN_VOLVER_P1_RADICACION = "URL_REST_CARGA_DOCUMENTAL_BTN_VOLVER";
	public static final String URL_REST_CONSULTA_FORMATO_RECLAMACION = "URL_REST_CONSULTA_FORMATO_RECLAMACION";
	public static final String LISTA_JASPER = "VJListaJasper";
	public static final String LISTA_IMAGENES_JASPER = "VJListaJasperImagenes";
	public static final String LISTA_PARAMETROS_ADJ_DOCUMENTOS = "VJListaParametrosAdjunta";
	public static final String LISTA_PROPIEDADES = "ListaPropiedadesGlobalPrincipal";
	public static final String LISTA_VERSION_FORMATOS_JASPER = "ListaVersionFormatosJasper";
	public static final String ID = "id";
	public static final String BENEFICIARIO = "beneficiario";
	public static final String BENEFICIARIOS = "beneficiarios";
	public static final String BENEFICIARIO_ID = "beneficiarioId";
	public static final String PARENTESCO = "parentesco";
	public static final String FECHA = "fecha";

	public static final String VERSION_ANEXOS_VEJEZ = "AnexosVejez";
	public static final String ID_JASPER = "idJasper";
	public static final String URL_JASPER_ARCHIVO = "UrlArchivoJasper";
	public static final String URL_SERVICIO_JASPER = "UrlServicioJasper";
	public static final String ID_JASPER_PADRE = "idReportePadre";
	public static final String URL_DATA_INFORME = "URL_DATA_INFORME_";
	public static final String NOMBRE_JASPER = "NombreJasper";

	public static final String OTP = "otp";
	public static final String COD_200 = "200";
	public static final String BOTON_CONTINUAR_FIRMA_ELECTRONICA = "Continuar y firmar en firma electronica";

	public static final String NOMBRE_IMAGEN = "NombreImagen";
	public static final String URL_IMAGEN_JASPER = "UrlImagen";
	public static final String ID_JASPER_PADRE_IMAGEN = "idJasperPadre";

	public static final String REPORTE_LOCALE = "REPORT_LOCALE";
	public static final String REPORTE_VERSION_DOC = "VERSION_DOC";
	public static final String URL_REDIRRECCION = "url";

	/**
	 * Parametros documentos
	 */
	public static final String ID_SOLICITUD = "idSolicitud";
	public static final String PESO_DOCUMENTOS = "pesoDocumentos";
	public static final String CANTIDAD_DOCUMENTOS = "cantidadDocumentos";

	/**
	 * parametros logs bodega
	 */
	public static final String INICIALIZA = "Inicializa radicacion";
	public static final String CONSULTA_LISTA_DOCUMENTAL_RADICACION_VEJEZ = "Consulta lista docs, (VJ-CONSULTAR DOCUMENTOS RADICACION)";
	public static final String CARGAR_RADICACION_VEJEZ = "Cargar documentos, (VJ-CARGAR DOCUMENTOS RADICACION)";
	public static final String BTN_DESCARGA_DOCUMENTO_ONBASE = "Descargar archivo,(DESCARGA_DOCUMENTO ONBASE)";
	public static final String BTN_DESCARGA_DOCUMENTO_HL = "Descargar archivo,(DESCARGA_DOCUMENTO HL)";
	public static final String GENERACION_REPORTE = "Cargar archivo,(GENERAR_REPORTE JASPER)";
	public static final String BTN_GUARDAR_Y_CONTINUAR_ADJ1 = " Guardar y continuar (BTN GUARDAR EN ADJUNTA_RADICACION)";
	public static final String BTN_GUARDAR_Y_CONTINUAR_ADJ2 = "Finalizar Transaccion,(BTN GUARDAR EN RADICACION_VALIDACION)";
	public static final String FIRMA_ELECTRONICA = "Firmar,(FIRMA ELECTRONICA RADICACION)";
	public static final String BTN_ELIMINAR_DOCUMENTO = "ELIMINAR DOCUMENTOS ASOCIADOS ADJUNTA RADICACION";

	public static final String ID_DOCUMENTO_FORMULARIO_RECLAMACION = "236";
	public static final String ID_DOCUMENTO_CONTRATO_RETIRO_PROGRAMADO = "1001";

	/**
	 * Tipos de beneficios de pension
	 */
	public static final String NO_DERECHO_PENSION_ANTICIPADA = "1";
	public static final String MESADA_ANTICIPADA = "2";
	public static final String MESADA_ANTICIPADA_EXCEDENTES = "3";
	public static final String MESADA_PENSIONAL = "4";
	public static final String MESADA_PENSIONAL_EXCEDENTES = "5";
	public static final String GARANTIA_PENSION_MINIMA = "6";
	public static final String DEVOLUCION_SALDOS = "7";
	public static final String NUEVA_MODALIDAD = "8";
	public static final String ESPERAR_RED_NORMAL_BONO = "9";
	public static final String ESPERAR_ACREDITACION_BONO = "10";
	public static final String COTIZACION_RENTA = "11";

	public static final String ID_DOCUMENTO_CHL = "165";
}