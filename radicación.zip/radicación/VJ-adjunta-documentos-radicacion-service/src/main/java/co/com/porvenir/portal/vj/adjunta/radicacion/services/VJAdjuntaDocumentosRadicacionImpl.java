package co.com.porvenir.portal.vj.adjunta.radicacion.services;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.cache.MultiVMPool;
import com.liferay.portal.kernel.cache.PortalCache;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.registry.Registry;
import com.liferay.registry.RegistryUtil;
import com.liferay.registry.ServiceReference;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64.Decoder;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.portlet.PortletRequest;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import co.com.porvenir.portal.api.reportes.ReportesApi;
import co.com.porvenir.portal.api.reportes.exception.ReportesApiException;
import co.com.porvenir.portal.clientesws.rest.api.RestClientApi;
import co.com.porvenir.portal.clientesws.rest.api.RestClientApiConstant;
import co.com.porvenir.portal.util.api.UtilApi;
import co.com.porvenir.portal.util.constants.UtilKeys;
import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApiKeys;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionImplPortletKeys;

/**
 * @author POR09646
 */
@Component(immediate = true, property = {}, service = VJAdjuntaDocumentosRadicacionApi.class)
public class VJAdjuntaDocumentosRadicacionImpl implements VJAdjuntaDocumentosRadicacionApi {

	@Reference
	private DinamicDatalistApi dataListApi;

	@Reference
	private RestClientApi restApi;

	@Reference
	private UtilApi utilApi;

	@Reference
	private ReportesApi reportesApi;

	private static Log log = LogFactoryUtil.getLog(VJAdjuntaDocumentosRadicacionImpl.class);

	@Override
	public JSONObject cargarDocumento(PortletRequest request, boolean esPdf, String idDocumento, String idBeneficiario,
			JSONArray imagenesBase64) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);

		String urlServicio = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_VJ_CARGA_DOCUMENTAL_RADICACION);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		JSONObject peticion = JSONFactoryUtil.createJSONObject();

		peticion.put("documentoEsPdf", esPdf);
		peticion.put("idBeneficiario", idBeneficiario);
		peticion.put("idDocumento", idDocumento);
		peticion.put("imagenesBase64", imagenesBase64);

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.CONSULTA_LISTA_DOCUMENTAL_RADICACION_VEJEZ,
					request.getPortletSession().getId());

			respuesta = restApi.callRestServiceByPost(urlServicio, peticion.toJSONString(), headers,
					new LinkedHashMap<>(), logParams);

			if (respuesta.getInt(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO) == RestClientApiConstant.SC_OK_OTP) {
				if (respuesta.has(UtilKeys.JWT)) {
					String jwtNuevo = respuesta.getString(UtilKeys.JWT);
					PortalCache portalCache = multiVMPool
							.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
					portalCache.put(UtilKeys.JWT, jwtNuevo);
				}
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK);
			} else {
				log.error("Error en servicio cargar documentos radicacion: " + respuesta);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			log.error("Error en servicio cargar documentos radicacion");
			log.error(e.getMessage());
		}
		return respuesta;
	}

	MultiVMPool multiVMPool = getMultiVMPool();

	private MultiVMPool getMultiVMPool() {
		Registry registry = RegistryUtil.getRegistry();
		ServiceReference serviceReference = registry.getServiceReference(MultiVMPool.class);
		return (MultiVMPool) registry.getService(serviceReference);
	}

	@Override
	public JSONObject eliminarDocumento(PortletRequest request, String idDocumento, String idBeneficiario) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);

		String urlServicio = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_ELIMINAR_DOCUMENTO_RADICACION);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.BTN_ELIMINAR_DOCUMENTO, request.getPortletSession().getId());

			LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
			urlServicio += "/" + idDocumento;
			urlServicio += "/" + VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIO + "/" + idBeneficiario;
			respuesta = restApi.callRestServiceByDelete(urlServicio, headers, parameters, logParams);

			if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK_OTP) {
				if (respuesta.has(UtilKeys.JWT)) {
					String jwtNuevo = respuesta.getString(UtilKeys.JWT);
					PortalCache portalCache = multiVMPool
							.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
					portalCache.put(UtilKeys.JWT, jwtNuevo);
				}
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK);
			} else {
				log.error("Error en servicio eliminar documento-VJ radicacion");
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error en servicio eliminar documento-VJ radicacion");
			log.error(e);
		}
		return respuesta;
	}

	@Override
	public InputStream descargarDocumento(PortletRequest request, String idDocumento, String idBeneficiario) {
		String documento;

		try {
			JSONArray listaReportes = dataListApi.getAllList(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_JASPER,
					new String[] { VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER });

			boolean estaEnLista = false;
			for (int i = 0; i < listaReportes.length(); i++) {
				JSONObject reporte = listaReportes.getJSONObject(i);
				if (idDocumento.equals(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER))) {
					estaEnLista = true;
					break;
				}
			}

			if (idDocumento.equals(VJAdjuntaDocumentosRadicacionApiKeys.ID_DOCUMENTO_CHL)) {
				JSONObject hl = descargarArchivoHL(request);
				return base64ToOutputStream(hl.getString(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO));
			} else if (estaEnLista) {
				String jasper = generarJasper(request, idDocumento);
				return base64ToOutputStream(jasper);
			} else {
				documento = consumirServicioDescargaOnbase(request, idDocumento, idBeneficiario);
				return base64ToOutputStream(documento);
			}

		} catch (Exception e) {
			log.error("Error en descargarDocumento id:" + idDocumento);
			log.error(e.getMessage());
		}
		return null;
	}

	@Override
	public JSONObject descargarDocumentoAdjunta2(PortletRequest request, String idDocumento, String idBeneficiario) {
		String documento;

		JSONObject response = JSONFactoryUtil.createJSONObject();

		if (idDocumento.equals("165")) {
			JSONObject hl = descargarArchivoHL(request);
			response.put("documento",
					base64ToOutputStream(hl.getString(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO)));
			return response;
		} else {
			JSONObject respuestaServicio = JSONFactoryUtil.createJSONObject();
			respuestaServicio = consumirServicioDescargaOnbaseAdjunta2(request, idDocumento, idBeneficiario);
			documento = respuestaServicio.getString(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO);
			base64ToOutputStream(documento);

			response.put("documento", base64ToOutputStream(documento));

			return response;
		}
	}

	@Override
	public InputStream descargaDocumentoOnBase(PortletRequest request, String idDocumento, String idBeneficiario) {
		String documento;
		documento = consumirServicioDescargaOnbase(request, idDocumento, idBeneficiario);
		if (!documento.equals("documentoNoEncontrado")) {
			return base64ToOutputStream(documento);
		} else {
			return null;
		}
	}

	@Override
	public InputStream generarDocumentoAsOutputStream(PortletRequest request, String idDocumento) {
		try {
			String documento = generarJasper(request, idDocumento);
			return base64ToOutputStream(documento);
		} catch (Exception e) {
			log.error("no se pudo convertir de string a base 64");
		}
		return null;
	}

	@Override
	public String generarDocumentoAsBase64(PortletRequest request, String idDocumento) {
		return generarJasper(request, idDocumento);
	}

	@Override
	public JSONObject consultarListaDocumentos(PortletRequest request) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);

		String urlServicio = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_CONSULTAR__LISTA_DOCUMENTOS_RADICACION);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.CONSULTA_LISTA_DOCUMENTAL_RADICACION_VEJEZ,
					request.getPortletSession().getId());

			respuesta = restApi.callRestServiceByGet(urlServicio, headers, new LinkedHashMap<>(), logParams);

			if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK) {
				PortalCache portalCache = multiVMPool
						.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
				portalCache.put(UtilKeys.JWT, respuesta.getString(UtilKeys.JWT));
				respuesta = respuesta.getJSONObject(RestClientApiConstant.RESPUESTA);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK);
			} else {
				log.error("Error en respuesta del servicio CONSULTA LISTA DOCUMENTAL RADICACION VEJEZ, codigo: "
						+ respuesta.getInt(RestClientApiConstant.CODIGO));
				log.error(respuesta);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error en respuesta del servicio CONSULTA LISTA DOCUMENTAL RADICACION VEJEZ");
			log.error(e);
		}
		return respuesta;
	}

	@Override
	public JSONObject guardarAdjunta(PortletRequest request) {

		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(request));
		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		String urlRedireccion = StringPool.BLANK;
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);

		String urlServicio = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_VJ_GUARDAR_CARGA_DOCUMENTAL_RADICACION);

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.BTN_GUARDAR_Y_CONTINUAR_ADJ2,
					request.getPortletSession().getId());

			respuesta = restApi.callRestServiceByGet(urlServicio, headers, new LinkedHashMap<>(), logParams);

			if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK) {

				if (respuesta.has(UtilKeys.JWT)) {
					String jwtNuevo = respuesta.getString(UtilKeys.JWT);
					PortalCache portalCache = multiVMPool
							.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
					portalCache.put(UtilKeys.JWT, jwtNuevo);
				}

				if (!respuesta.getJSONObject(RestClientApiConstant.RESPUESTA).getBoolean("bloqueadoPorActividadBpm")) {
					String pasoTransaccion = respuesta.getJSONObject(RestClientApiConstant.RESPUESTA).getString("paso");
					String idBeneficio = respuesta.getJSONObject(RestClientApiConstant.RESPUESTA)
							.getString("beneficioAlcanzado");

					if (!pasoTransaccion.equals("") && pasoTransaccion.equals("VEJEZ_PASO_3_ADJUNTA_DOCUMENTOS")) {
						urlRedireccion = "/adjunta-documentos-radicacion-p1.jsp";
					} else if (!pasoTransaccion.equals("")
							&& pasoTransaccion.equals("VEJEZ_PASO_3_FIRMA_ELECTRONICA_RADICACION")) {
						urlRedireccion = "/firma-electronica-radicacion.jsp";
					} else if (!pasoTransaccion.equals("")
							&& pasoTransaccion.equals("VEJEZ_PASO_3_ADJUNTA_DOCUMENTOS_RADICACION_VALIDACION")) {

						JSONObject requestTx = JSONFactoryUtil.createJSONObject();
						requestTx.put("idBeneficio", idBeneficio);
						requestTx.put("pasoTransaccion", pasoTransaccion);
						JSONObject urlNavegacion = utilApi.generarNavegacionVejez(
								utilApi.getJWT(tipoIdentificacion, identificacion), requestTx,
								PortalUtil.getHttpServletRequest(request));

						urlRedireccion = urlNavegacion.getString("url");
						httpReq.getSession().setAttribute("pasoTransaccion", urlNavegacion.getString("tipoBeneficio"));
					}

					respuesta.put("urlRedireccion", urlRedireccion);

				}

			} else {
				log.error("Error en respuesta del servicio guardar de carga documental radicacion, codigo: "
						+ respuesta.getInt(RestClientApiConstant.CODIGO));
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error en servicio regresar de carga documental radicacion");
			log.error(e);
		}
		return respuesta;
	}

	private String consumirServicioDescargaOnbase(PortletRequest request, String idDocumento, String idBeneficiario) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);

		String documentoNoEncontrado = "documentoNoEncontrado";

		String urlServicio = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_DESCARGAR_DOCUMENTOS_RADICACION);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.BTN_DESCARGA_DOCUMENTO_ONBASE,
					request.getPortletSession().getId());

			LinkedHashMap<String, String> parameters = new LinkedHashMap<>();

			urlServicio += "/" + idDocumento + "/";
			urlServicio += VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIO + "/" + idBeneficiario;
			respuesta = restApi.callRestServiceByGet(urlServicio, headers, parameters, logParams);

			if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK) {
				PortalCache portalCache = multiVMPool
						.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
				portalCache.put(UtilKeys.JWT, respuesta.getString(UtilKeys.JWT));
				respuesta = respuesta.getJSONObject(RestClientApiConstant.RESPUESTA);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK);
			} else if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK_OTP) {
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK_OTP);
			} else {
				log.error("Error en descargar documentos: " + respuesta.getInt(RestClientApiConstant.CODIGO));
				log.error(respuesta);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
				respuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO, StringPool.BLANK);
			}
		} catch (Exception e) {
			respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			respuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO, StringPool.BLANK);
			log.error("Error en servicio descargar documentos Onbase");
			log.error(e);
		}
		if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK) {
			return respuesta.getString(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO);
		} else {
			return documentoNoEncontrado;
		}
	}

	private JSONObject consumirServicioDescargaOnbaseAdjunta2(PortletRequest request, String idDocumento,
			String idBeneficiario) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);

		String documentoNoEncontrado = "documentoNoEncontrado";
		String urlServicio = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_DESCARGAR_DOCUMENTOS_RADICACION);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					StringPool.BLANK, request.getPortletSession().getId());
			logParams.put(RestClientApiConstant.COMPONENTE, "DESCARGAR DOCUMENTOS");

			LinkedHashMap<String, String> parameters = new LinkedHashMap<>();

			urlServicio += "/" + idDocumento + "/";
			urlServicio += VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIO + "/" + idBeneficiario;
			respuesta = restApi.callRestServiceByGet(urlServicio, headers, parameters, logParams);

			if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK) {
				PortalCache portalCache = multiVMPool
						.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
				portalCache.put(UtilKeys.JWT, respuesta.getString(UtilKeys.JWT));
				respuesta = respuesta.getJSONObject(RestClientApiConstant.RESPUESTA);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK);
			} else if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK_OTP) {
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK_OTP);
			} else {
				log.error("Error en descargar documentos: " + respuesta.getInt(RestClientApiConstant.CODIGO));
				log.error(respuesta);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
				respuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO, StringPool.BLANK);
			}
		} catch (Exception e) {
			respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			respuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO, StringPool.BLANK);
			log.error("Error en servicio descargar documentos");
			log.error(e);
		}

		return respuesta;
	}

	@Override
	public JSONObject guardarFirma(PortletRequest request) {
		JSONObject documents = this.consultarListaDocumentos(request);
		
		JSONArray listDocumentos = documents.getJSONArray(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_DOCUMENTOS);
		JSONArray listDocumentosParaFirma = JSONFactoryUtil.createJSONArray();
		
		JSONObject jsonRequest = JSONFactoryUtil.createJSONObject();
		String documento;

		// Validar que documentos requieren firma
		for (int i = 0; i < listDocumentos.length(); i++) {
			JSONObject objects = listDocumentos.getJSONObject(i);
			if (objects.getBoolean("requiereFirmaElectronica")) {
				if (!objects.getBoolean(VJAdjuntaDocumentosRadicacionApiKeys.ESTA_FIRMADO) || objects.getInt("estadoDocumento") == 1) {
					JSONObject documentoGenerado = JSONFactoryUtil.createJSONObject();
					String idDocumento = objects.getString(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO_ID);
					String idBeneficiario = objects.getString("idBeneficiario");
					documento = generarDocumentoBase64(request, idDocumento, idBeneficiario);

					documentoGenerado.put(VJAdjuntaDocumentosRadicacionApiKeys.ID, idDocumento);
					documentoGenerado.put("contenido", documento.replaceAll("\n", ""));
					listDocumentosParaFirma.put(documentoGenerado);
				}
			}
		}
		// Request Service
		jsonRequest.put(VJAdjuntaDocumentosRadicacionApiKeys.OTP,
				inicializaParametro(request, VJAdjuntaDocumentosRadicacionApiKeys.OTP));
		jsonRequest.put(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_DOCUMENTOS, listDocumentosParaFirma);
		return consumoServicioFirma(request, jsonRequest);
	}

	public String generarDocumentoBase64(PortletRequest request, String idDocumento, String idBeneficiario) {
		JSONArray listaReportes = dataListApi.getAllList(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_JASPER,
				new String[] { VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER });

		boolean estaEnLista = false;
		for (int i = 0; i < listaReportes.length(); i++) {
			JSONObject reporte = listaReportes.getJSONObject(i);
			if (idDocumento.equals(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER))) {
				estaEnLista = true;
				break;
			}
		}

		if (idDocumento.equals(VJAdjuntaDocumentosRadicacionApiKeys.ID_DOCUMENTO_CHL)) {
			JSONObject hl = descargarArchivoHL(request);
			return hl.getString(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO);
		} else if (estaEnLista) {
			return generarJasper(request, idDocumento);
		} else {
			return consumirServicioDescargaOnbase(request, idDocumento, idBeneficiario);
		}

	}

	private JSONObject consumoServicioFirma(PortletRequest request, JSONObject peticion) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);

		String urlService = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_FIRMA_ELECTRONICA_RADICACION);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.FIRMA_ELECTRONICA, request.getPortletSession().getId());

			respuesta = restApi.callRestServiceByPost(urlService, peticion.toJSONString(), headers,
					new LinkedHashMap<>(), logParams);

			if (respuesta.getString(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO)
					.equals(VJAdjuntaDocumentosRadicacionApiKeys.COD_200)) {

				PortalCache portalCache = multiVMPool
						.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
				portalCache.put(UtilKeys.JWT, respuesta.getString(UtilKeys.JWT));
			}
		} catch (Exception e) {
			respuesta = JSONFactoryUtil.createJSONObject();
			log.error("Error en servicio Firmar radicacion");
			log.error(e.getMessage());
		}
		log.info("Codigo respuesta servicio VJ-Firma Electronica Radicacion: "
				+ respuesta.getString(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO));
		return respuesta;
	}

	public String inicializaParametro(PortletRequest request, String nombreParametro) {
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(request));
		String parametro = (String) httpReq.getSession().getAttribute(nombreParametro);
		if (parametro == null || parametro.equals(StringPool.BLANK)) {
			log.error("No se encuentra " + nombreParametro + " al inicializar el servicio");
		}
		return parametro;
	}

	private InputStream base64ToOutputStream(String base64) {

		Decoder dec = java.util.Base64.getDecoder();
		byte[] imgBytes = dec.decode(base64.replaceAll("\n", ""));
		return new ByteArrayInputStream(imgBytes);
	}

	private JSONObject consumoServicioDataReporte(PortletRequest request, String idDocumento, String urlService) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);
		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		Map<String, String> headers;
		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		try {
			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);
			
			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");

			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.GENERACION_REPORTE, request.getPortletSession().getId());

			respuesta = restApi.callRestServiceByGet(urlService, headers, new LinkedHashMap<>(), logParams);

			if (respuesta.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK) {
				PortalCache portalCache = multiVMPool
						.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
				portalCache.put(UtilKeys.JWT, respuesta.getString(UtilKeys.JWT));
				respuesta = respuesta.getJSONObject(RestClientApiConstant.RESPUESTA);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_OK);
			} else {
				log.error("Error generando reporte " + idDocumento);
				log.error(respuesta);
				respuesta.put(RestClientApiConstant.CODIGO, RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error generando reporte " + idDocumento + " identificacion: " + identificacion);
			log.error(e);
		}
		return respuesta;

	}

	private String generarJasper(PortletRequest request, String idDocumento) {
		Map<String, Object> params = new HashMap<>();
		Map<String, String> subReportes = new HashMap<>();
		String urlJasper = StringPool.BLANK;
		String urlServicio = StringPool.BLANK;
		JSONObject data;
		String version_doc = "1";

		String tipoBeneficio = inicializaParametro(request, UtilKeys.TIPO);// getTipo();

		String nombreJasperFormulario = StringPool.BLANK;
		JSONArray listaReportes;

		listaReportes = dataListApi.getAllList(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_JASPER,
				new String[] { VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER,
						VJAdjuntaDocumentosRadicacionApiKeys.URL_JASPER_ARCHIVO,
						VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER_PADRE,
						VJAdjuntaDocumentosRadicacionApiKeys.NOMBRE_JASPER,
						VJAdjuntaDocumentosRadicacionApiKeys.URL_SERVICIO_JASPER });

		// Se obtiene el jasper del formulario idBeneficio
		if (idDocumento.equals(VJAdjuntaDocumentosRadicacionApiKeys.ID_DOCUMENTO_FORMULARIO_RECLAMACION)) {

			if (tipoBeneficio.equals(VJAdjuntaDocumentosRadicacionApiKeys.NO_DERECHO_PENSION_ANTICIPADA)
					|| tipoBeneficio.equals(VJAdjuntaDocumentosRadicacionApiKeys.MESADA_PENSIONAL)
					|| tipoBeneficio.equals(VJAdjuntaDocumentosRadicacionApiKeys.MESADA_ANTICIPADA)) {
				nombreJasperFormulario = "formularioVejezNormalYAnticipada";
			} else if (tipoBeneficio.equals(VJAdjuntaDocumentosRadicacionApiKeys.GARANTIA_PENSION_MINIMA)) {
				nombreJasperFormulario = "formularioGPM";
			} else {
				nombreJasperFormulario = "formularioDevolucionSaldos";
			}

			for (int i = 0; i < listaReportes.length(); i++) {
				JSONObject reporte = listaReportes.getJSONObject(i);

				if (nombreJasperFormulario
						.equals(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.NOMBRE_JASPER))) {
					urlJasper = reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_JASPER_ARCHIVO);
					urlServicio = reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_SERVICIO_JASPER);
				}
				if (idDocumento.equals(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER_PADRE))) {
					subReportes.put(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.NOMBRE_JASPER),
							reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_JASPER_ARCHIVO));
				}
			}

		} else {

			listaReportes = dataListApi.getAllList(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_JASPER,
					new String[] { VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER,
							VJAdjuntaDocumentosRadicacionApiKeys.URL_JASPER_ARCHIVO,
							VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER_PADRE,
							VJAdjuntaDocumentosRadicacionApiKeys.NOMBRE_JASPER,
							VJAdjuntaDocumentosRadicacionApiKeys.URL_SERVICIO_JASPER });

			for (int i = 0; i < listaReportes.length(); i++) {
				JSONObject reporte = listaReportes.getJSONObject(i);
				if (idDocumento.equals(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER))) {
					urlJasper = reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_JASPER_ARCHIVO);
					urlServicio = reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_SERVICIO_JASPER);
				}
				if (idDocumento.equals(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER_PADRE))) {
					subReportes.put(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.NOMBRE_JASPER),
							reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_JASPER_ARCHIVO));
				}
			}
		}
		JSONArray listaImagenes = dataListApi.getAllList(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_IMAGENES_JASPER,
				new String[] { VJAdjuntaDocumentosRadicacionApiKeys.NOMBRE_IMAGEN,
						VJAdjuntaDocumentosRadicacionApiKeys.URL_IMAGEN_JASPER,
						VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER_PADRE_IMAGEN });

		for (int i = 0; i < listaImagenes.length(); i++) {
			JSONObject reporte = listaReportes.getJSONObject(i);
			if (idDocumento.equals(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.ID_JASPER_PADRE_IMAGEN))) {
				try {
					URL url = new URL(reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_IMAGEN_JASPER));
					Image ima = ImageIO.read(url);
					params.put(VJAdjuntaDocumentosRadicacionApiKeys.NOMBRE_IMAGEN, ima);
				} catch (IOException e) {
					log.error("No se pudo generar imagen a partir de url: "
							+ reporte.getString(VJAdjuntaDocumentosRadicacionApiKeys.URL_IMAGEN_JASPER));
				}
			}
		}

		data = consumoServicioDataReporte(request, idDocumento, urlServicio);
		if (data.getJSONArray(VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIOS) != null
				&& idDocumento.equals(VJAdjuntaDocumentosRadicacionApiKeys.ID_DOCUMENTO_CONTRATO_RETIRO_PROGRAMADO)) {
			JSONArray beneficiarios = data.getJSONArray(VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIOS),
					listaBeneficiarioTitular = JSONFactoryUtil.createJSONArray();

			JSONObject beneficiarioTitular = JSONFactoryUtil.createJSONObject();
			for (int i = 0; i < beneficiarios.length(); i++) {
				JSONObject beneficiario = beneficiarios.getJSONObject(i);
				if (beneficiario.getInt(VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIO_ID) == 1
						|| beneficiario.getString(VJAdjuntaDocumentosRadicacionApiKeys.PARENTESCO).equals("Titular")) {
					beneficiarioTitular = beneficiario;
					break;
				}
			}

			data.remove(VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIOS);
			listaBeneficiarioTitular.put(beneficiarioTitular);
			data.put(VJAdjuntaDocumentosRadicacionApiKeys.BENEFICIARIOS, listaBeneficiarioTitular);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String fecha = sdf.format(new Date());
		data.put(VJAdjuntaDocumentosRadicacionApiKeys.FECHA, fecha);
		if (data.getInt("codigo") == 200) {

			if (idDocumento.equals("192") || idDocumento.equals("96") || idDocumento.equals("214")
					|| idDocumento.equals("1001")) {
				version_doc = dataListApi.getRecordValue(
						VJAdjuntaDocumentosRadicacionApiKeys.LISTA_VERSION_FORMATOS_JASPER,
						VJAdjuntaDocumentosRadicacionApiKeys.VERSION_ANEXOS_VEJEZ);
			}

			params.put(VJAdjuntaDocumentosRadicacionApiKeys.REPORTE_LOCALE, new Locale("es"));
			params.put(VJAdjuntaDocumentosRadicacionApiKeys.REPORTE_VERSION_DOC, version_doc);
			try {
				return reportesApi.generarPdf(urlJasper, params, data, subReportes);
			} catch (ReportesApiException e) {
				log.error("Error generando jasper " + idDocumento);
				log.error(e);
				return StringPool.BLANK;
			}
		} else {
			log.error("Error generando jasper " + idDocumento);
			log.error(data);
			return StringPool.BLANK;
		}

	}

	private JSONObject descargarArchivoHL(PortletRequest request) {
		String tipoIdentificacion = inicializaParametro(request, UtilKeys.TIPO_IDENTIFICACION);
		String identificacion = inicializaParametro(request, UtilKeys.IDENTIFICACION);
		String tipo = inicializaParametro(request, UtilKeys.TIPO);
		String blankBase64Pdf1 = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionImplPortletKeys.BLANK_BASE_64_PDF_1_ID);
		String blankBase64Pdf2 = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionImplPortletKeys.BLANK_BASE_64_PDF_2_ID);
		String blankBase64Pdf3 = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionImplPortletKeys.BLANK_BASE_64_PDF_3_ID);
		String blankBase64Pdf4 = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionImplPortletKeys.BLANK_BASE_64_PDF_4_ID);

		JSONObject jsonRespuesta = JSONFactoryUtil.createJSONObject();

		JSONObject logParams = JSONFactoryUtil.createJSONObject();
		String urlService = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
				VJAdjuntaDocumentosRadicacionApiKeys.URL_REST_CONSULTA_FORMATO_HL);

		try {
			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PROPIEDADES,
					RestClientApiConstant.URL_REST_LOGS);

			String urlPage = PortalUtil.getCurrentURL(request);
			String[] urlStp = urlPage.split("\\?");
			
			logParams = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion,
					identificacion, StringPool.BLANK, request.getContextPath(), urlStp[0],
					VJAdjuntaDocumentosRadicacionApiKeys.BTN_DESCARGA_DOCUMENTO_HL,
					request.getPortletSession().getId());

			Map<String, String> headers;

			headers = restApi.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			headers.put(UtilKeys.AUTHORIZATION, utilApi.getJWT(tipoIdentificacion, identificacion));

			JSONObject jsonRespuestaPlantillaHL = restApi.callRestServiceByGet(urlService, headers,
					new LinkedHashMap<>(), logParams);
			log.info("Code descargarArchivoHL: " + jsonRespuestaPlantillaHL.getInt(RestClientApiConstant.CODIGO));
			if (jsonRespuestaPlantillaHL.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_OK
					&& jsonRespuestaPlantillaHL.has(RestClientApiConstant.RESPUESTA)) {
				// jwt - descarga plantillas
				String jwtNuevo = jsonRespuestaPlantillaHL.getString(RestClientApiConstant.JWT);
				PortalCache portalCache = multiVMPool
						.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
				portalCache.put(RestClientApiConstant.JWT, jwtNuevo);

				String reporte = jsonRespuestaPlantillaHL.getJSONObject(RestClientApiConstant.RESPUESTA)
						.getString(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO);
				jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO, reporte);

			} else if (jsonRespuestaPlantillaHL
					.getInt(RestClientApiConstant.CODIGO) == RestClientApiConstant.SC_INTERNAL_SERVER_ERROR) {
				if (tipo == UtilKeys.ID_GPM || tipo == UtilKeys.ID_VEJEZ_NORMAL) {
					String jwtNuevo = jsonRespuestaPlantillaHL.getString(RestClientApiConstant.JWT);
					PortalCache portalCache = multiVMPool
							.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
					portalCache.put(RestClientApiConstant.JWT, jwtNuevo);
					String reporte = blankBase64Pdf1 + blankBase64Pdf2 + blankBase64Pdf3 + blankBase64Pdf4;
					jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.DOCUMENTO, reporte);
					jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO, RestClientApiConstant.SC_OK);
					return jsonRespuesta;
				}
			} else {
				jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO,
						RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
			jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO,
					jsonRespuestaPlantillaHL.getInt(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO));
		} catch (Exception e) {
			jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.CODIGO,
					RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			log.error("Error en consulta servicio HL");
			log.error(e.getMessage());
		}
		return jsonRespuesta;
	}

	public JSONObject getParametrosDocumentos(String idSolicitud) {

		JSONObject jsonRespuesta = JSONFactoryUtil.createJSONObject();

		JSONArray listaParametros = dataListApi.getAllList(
				VJAdjuntaDocumentosRadicacionApiKeys.LISTA_PARAMETROS_ADJ_DOCUMENTOS,
				new String[] { VJAdjuntaDocumentosRadicacionApiKeys.ID_SOLICITUD,
						VJAdjuntaDocumentosRadicacionApiKeys.PESO_DOCUMENTOS,
						VJAdjuntaDocumentosRadicacionApiKeys.CANTIDAD_DOCUMENTOS });

		for (int i = 0; i < listaParametros.length(); i++) {
			JSONObject parametros = listaParametros.getJSONObject(i);
			if (idSolicitud.equals(parametros.getString(VJAdjuntaDocumentosRadicacionApiKeys.ID_SOLICITUD))) {
				jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.PESO_DOCUMENTOS,
						parametros.getString(VJAdjuntaDocumentosRadicacionApiKeys.PESO_DOCUMENTOS));
				jsonRespuesta.put(VJAdjuntaDocumentosRadicacionApiKeys.CANTIDAD_DOCUMENTOS,
						parametros.getString(VJAdjuntaDocumentosRadicacionApiKeys.CANTIDAD_DOCUMENTOS));
				break;
			}
		}

		return jsonRespuesta;
	}

}