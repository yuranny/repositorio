function errorServicio() {
	if (total > cont){
		$('#modalLoader').modal('hide');
		$('#modalGif').modal('hide');
		$('#errorGeneralServicioCerrar').modal('show');
		cont = cont + 1; 
	 }else{
		$('#modalLoader').modal('hide');
		$('#modalGif').modal('hide');
		$('#errorGeneralServicio').modal('show');
	 }
}

