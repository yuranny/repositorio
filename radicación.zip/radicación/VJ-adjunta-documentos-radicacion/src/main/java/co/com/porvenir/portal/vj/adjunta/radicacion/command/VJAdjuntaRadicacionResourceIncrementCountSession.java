package co.com.porvenir.portal.vj.adjunta.radicacion.command;

import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.IOException;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;

import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"javax.portlet.resource-bundle=content.Language", "mvc.command.name="
				+ VJAdjuntaDocumentosRadicacionPortletKeys.INCREMENTAR_COUNT }, service = MVCResourceCommand.class)

public class VJAdjuntaRadicacionResourceIncrementCountSession extends BaseMVCResourceCommand {

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {
		String accion = resourceRequest.getResourceID();
		if (accion.equals(VJAdjuntaDocumentosRadicacionPortletKeys.INCREMENTAR_COUNT)) {
			incrementCountSession(resourceRequest, resourceResponse);

		}
	}

	/**
	 * Metodo para incrementar conteo de intentos en error de servicios
	 * 
	 * @param resourceRequest
	 * @param resourceResponse
	 * @throws IOException
	 * @throws JSONException
	 */
	public void incrementCountSession(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException {

		HttpServletRequest httpReq = PortalUtil
				.getOriginalServletRequest(PortalUtil.getHttpServletRequest(resourceRequest));
		String numIntento = ParamUtil.getString(resourceRequest, VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION);
		httpReq.getSession().setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION, numIntento);
		JSONObject jsonResponse = JSONFactoryUtil.createJSONObject();
		jsonResponse.put(VJAdjuntaDocumentosRadicacionPortletKeys.CODIGO, 200);

		resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
		resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_JSON);
		resourceResponse.resetBuffer();
		resourceResponse.getWriter().print(jsonResponse);
		resourceResponse.flushBuffer();
	}

}
