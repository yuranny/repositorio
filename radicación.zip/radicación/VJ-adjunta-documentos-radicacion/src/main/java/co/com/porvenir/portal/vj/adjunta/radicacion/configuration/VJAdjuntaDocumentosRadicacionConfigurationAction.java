package co.com.porvenir.portal.vj.adjunta.radicacion.configuration;

import com.liferay.portal.kernel.portlet.ConfigurationAction;
import com.liferay.portal.kernel.portlet.DefaultConfigurationAction;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;

import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(configurationPolicy = ConfigurationPolicy.OPTIONAL, immediate = true, property = { "javax.portlet.name="
		+ VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion }, service = ConfigurationAction.class)

public class VJAdjuntaDocumentosRadicacionConfigurationAction extends DefaultConfigurationAction {

	public void processAction(PortletConfig portletConfig, ActionRequest actionRequest, ActionResponse actionResponse)
			throws Exception {

		String url = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_INGRESA);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_INGRESA, url);

		String urlHome = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_HOME);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_HOME, urlHome);

		String urlInformacionPago = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_INFORMACION_PAGO);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_INFORMACION_PAGO,
				urlInformacionPago);

		String urlZp = ParamUtil.getString(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_ZP);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_URL_ZP, urlZp);

		String diasContinuidad = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_DIAS_CONTINUIDAD);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_DIAS_CONTINUIDAD,
				diasContinuidad);

		String montoFirmaElectronica = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_MONTO_FIRMA_ELECTRONICA);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_MONTO_FIRMA_ELECTRONICA,
				montoFirmaElectronica);

		String urlFinalizaTransaccion = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.URL_FINALIZA_TRANSACCION);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.URL_FINALIZA_TRANSACCION,
				urlFinalizaTransaccion);

		String urlFirmaElectronica = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.URL_FIRMA_ELECTRONICA);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.URL_FIRMA_ELECTRONICA,
				urlFirmaElectronica);

		String pesoDocumentos = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PESO_DOCUMENTOS);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PESO_DOCUMENTOS, pesoDocumentos);

		String cantidadDocumentos = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.CANTIDAD_DOCUMENTOS);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.CANTIDAD_DOCUMENTOS, cantidadDocumentos);

		String imagenBuenaCalidad = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.IMAGEN_BUENA_CALIDAD);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.IMAGEN_BUENA_CALIDAD, imagenBuenaCalidad);

		String imagenMalaCalidad = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.IMAGEN_MALA_CALIDAD);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.IMAGEN_MALA_CALIDAD, imagenMalaCalidad);

		String logoPorvenir = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_LOGO_PORVENIR);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_LOGO_PORVENIR, logoPorvenir);

		String reporteConvenios = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_REPORTE_CONVENIOS_INTERNACIONALES);
		setPreference(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_REPORTE_CONVENIOS_INTERNACIONALES,
				reporteConvenios);

		String reporteFormularioDevolucionSaldos = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_REPORTE_FORMULARIO_DEVOLUCION_SALDOS);
		setPreference(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_REPORTE_FORMULARIO_DEVOLUCION_SALDOS,
				reporteFormularioDevolucionSaldos);

		String urlInforgrafiaHistoria = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.INFOGRAFIA_HISTORIA);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.INFOGRAFIA_HISTORIA,
				urlInforgrafiaHistoria);

		String activarAntivirus = ParamUtil.getString(actionRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_ACTIVAR_ANTIVIRUS);
		setPreference(actionRequest, VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_ACTIVAR_ANTIVIRUS,
				activarAntivirus);

		super.processAction(portletConfig, actionRequest, actionResponse);
	}
}
