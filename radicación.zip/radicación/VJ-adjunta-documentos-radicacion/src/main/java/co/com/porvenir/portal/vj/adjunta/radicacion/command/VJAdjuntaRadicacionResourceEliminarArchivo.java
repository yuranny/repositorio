package co.com.porvenir.portal.vj.adjunta.radicacion.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.ByteArrayInputStream;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"mvc.command.name="
				+ VJAdjuntaDocumentosRadicacionPortletKeys.RESOURCE_ADJUNTA_RADICACION_ELIMINAR }, service = MVCResourceCommand.class)
public class VJAdjuntaRadicacionResourceEliminarArchivo extends BaseMVCResourceCommand {

	@Reference
	private VJAdjuntaDocumentosRadicacionApi adjuntaRadicacionServices;

	private static Log log = LogFactoryUtil.getLog(VJAdjuntaRadicacionResourceCargarArchivo.class);

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {

		log.error("resourceRequest VJAdjuntaRadicacion-ResourceEliminarArchivo");
		String idDocumento = ParamUtil.getString(resourceRequest, VJAdjuntaDocumentosRadicacionPortletKeys.ID_DOCUMENTO,
				StringPool.BLANK);
		String idBeneficiario = ParamUtil.getString(resourceRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.ID_BENEFICIARIO, StringPool.BLANK);
		JSONObject respuesta = adjuntaRadicacionServices.eliminarDocumento(resourceRequest, idDocumento,
				idBeneficiario);

		// convertir respueta a stream

		byte[] imgBytes = respuesta.toJSONString().getBytes();
		ByteArrayInputStream inStream = new ByteArrayInputStream(imgBytes);

		resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
		resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_JSON);
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, "", inStream);

	}

}