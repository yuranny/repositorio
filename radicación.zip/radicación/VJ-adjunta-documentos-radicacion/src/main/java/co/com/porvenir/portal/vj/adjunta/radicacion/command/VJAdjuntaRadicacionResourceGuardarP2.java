package co.com.porvenir.portal.vj.adjunta.radicacion.command;

import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;

import java.io.ByteArrayInputStream;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.util.api.UtilApi;
import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"mvc.command.name="
				+ VJAdjuntaDocumentosRadicacionPortletKeys.RESOURCE_ADJUNTA_RADICACION_P2 }, service = MVCResourceCommand.class)
public class VJAdjuntaRadicacionResourceGuardarP2 extends BaseMVCResourceCommand {

	@Reference
	private VJAdjuntaDocumentosRadicacionApi adjuntaRadicacionService;

	@Reference
	private UtilApi utilApi;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {

		JSONObject respuesta = adjuntaRadicacionService.guardarAdjunta(resourceRequest);

		byte[] imgBytes = respuesta.toJSONString().getBytes();
		ByteArrayInputStream inStream = new ByteArrayInputStream(imgBytes);

		resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
		resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_JSON);
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, "", inStream);

	}

}
