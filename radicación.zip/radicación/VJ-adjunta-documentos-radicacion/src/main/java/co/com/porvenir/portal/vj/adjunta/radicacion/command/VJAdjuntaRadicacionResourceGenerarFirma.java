package co.com.porvenir.portal.vj.adjunta.radicacion.command;

import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;

import java.io.ByteArrayInputStream;
import java.util.ResourceBundle;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"javax.portlet.resource-bundle=content.Language", "mvc.command.name="
				+ VJAdjuntaDocumentosRadicacionPortletKeys.RESOURCE_FIRMA_RADICACION_GENERAR_FIRMA }, service = MVCResourceCommand.class)

public class VJAdjuntaRadicacionResourceGenerarFirma extends BaseMVCResourceCommand {

	@SuppressWarnings("unused")
	private static ResourceBundle rb = ResourceBundle.getBundle("content.Language");

	@Reference
	private VJAdjuntaDocumentosRadicacionApi adjuntaRadicacionService;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();

		respuesta = adjuntaRadicacionService.guardarFirma(resourceRequest);

		if (respuesta.getInt("codigo") == 200) {
			JSONObject documentos = JSONFactoryUtil.createJSONObject(respuesta.getString("respuesta"));
			JSONArray listDocumentos = documentos.getJSONArray("listadoDeDocumentos");
			for (int i = 0; i < listDocumentos.length(); i++) {
				JSONObject json = listDocumentos.getJSONObject(i);
				// Guardar en Session del portlet el contenido de cada documento
				resourceRequest.getPortletSession().setAttribute(
						VJAdjuntaDocumentosRadicacionPortletKeys.DOCUMENTO_ID + json.getString("id"),
						json.getString("contenido"));
			}
		}
		// convertir respuesta a stream
		byte[] imgBytes = respuesta.toJSONString().getBytes();
		ByteArrayInputStream inStream = new ByteArrayInputStream(imgBytes);

		resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
		resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_JSON);
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, "", inStream);

	}

}
