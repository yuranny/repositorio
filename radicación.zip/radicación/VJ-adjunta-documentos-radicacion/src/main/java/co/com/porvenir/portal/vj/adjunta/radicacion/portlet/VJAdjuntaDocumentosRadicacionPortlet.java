package co.com.porvenir.portal.vj.adjunta.radicacion.portlet;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import co.com.porvenir.portal.clientesws.rest.api.RestClientApi;
import co.com.porvenir.portal.clientesws.rest.api.RestClientApiConstant;
import co.com.porvenir.portal.util.api.UtilApi;
import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

/**
 * @author Cristian Guerra
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=Porvenir",
		"com.liferay.portlet.instanceable=true", "javax.portlet.display-name=VJ-adjunta-documentos-radicacion Portlet",
		"javax.portlet.init-param.template-path=/", "com.liferay.portlet.header-portlet-css=/css/main.css",
		"javax.portlet.init-param.view-template=/adjunta-documentos-radicacion-p1.jsp",
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class VJAdjuntaDocumentosRadicacionPortlet extends MVCPortlet {

	private static Log log = LogFactoryUtil.getLog(VJAdjuntaDocumentosRadicacionPortlet.class);

	private static ResourceBundle rb = ResourceBundle.getBundle("content.Language");

	@Reference
	private UtilApi utilApi;

	@Reference
	private VJAdjuntaDocumentosRadicacionApi adjuntaRadicacionService;

	@Reference
	private DinamicDatalistApi dataListApi;
	
	@Reference
	private RestClientApi rest;

	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {

		HttpServletRequest httpReq = PortalUtil
				.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest));
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.TIPO, adjuntaRadicacionService
				.inicializaParametro(renderRequest, VJAdjuntaDocumentosRadicacionPortletKeys.TIPO));
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.TIPO_IDENTIFICACION,
				adjuntaRadicacionService.inicializaParametro(renderRequest,
						VJAdjuntaDocumentosRadicacionPortletKeys.TIPO_IDENTIFICACION));
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.IDENTIFICACION, adjuntaRadicacionService
				.inicializaParametro(renderRequest, VJAdjuntaDocumentosRadicacionPortletKeys.IDENTIFICACION));

		JSONObject documents = adjuntaRadicacionService.consultarListaDocumentos(renderRequest);
		int codeResponse = documents.getInt("codigo");
		if (codeResponse == 200) {
			boolean puedeVolver = documents.getBoolean("puedoRegresar");
			boolean puedoVisualizarHlo = documents.getBoolean("puedoVisualizarHlo");

			renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.REGRESAR, puedeVolver);
			renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.PUEDO_VISUALIZAR_HLO,
					puedoVisualizarHlo);

		}
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CODIGO, codeResponse);

		JSONObject listParams = dataListApi.getServiceValue(VJAdjuntaDocumentosRadicacionPortletKeys.LIST_PARAMS,
				VJAdjuntaDocumentosRadicacionPortletKeys.TOTALINTENTOS);
		String totalIntentos = listParams.getString("url");
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.TOTAL_INTENTOS, totalIntentos);

		JSONObject paramsCargarDocumentos = JSONFactoryUtil.createJSONObject();
		paramsCargarDocumentos = adjuntaRadicacionService.getParametrosDocumentos(adjuntaRadicacionService
				.inicializaParametro(renderRequest, VJAdjuntaDocumentosRadicacionPortletKeys.TIPO));
		renderRequest.setAttribute("paramsCargarDocumentos", paramsCargarDocumentos);

		String pasoTransaccion = "";

		String countSesion = "0";
		if (httpReq.getSession().getAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION) != null) {
			countSesion = (String) httpReq.getSession()
					.getAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION);
		}
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION, countSesion);

		JSONObject jsonObject  = JSONFactoryUtil.createJSONObject();
		String tipoIdentificacion = (String) httpReq.getSession().getAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.TIPO_IDENTIFICACION);
		String identificacion = (String) httpReq.getSession().getAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.IDENTIFICACION);
		
		if (codeResponse == 200) {
			JSONArray documentosConfigurados = getDocumentosConfigurados(
					documents.getJSONArray(VJAdjuntaDocumentosRadicacionPortletKeys.LISTA_DOCUMENTOS),
					documents.getJSONArray("listaBeneficiarios"));
			httpReq.getSession().setAttribute("requiereFirma", requiereFirmaElectronica(documentosConfigurados));
			renderRequest.setAttribute("requiereDocCargar", requiereDocCargar(documentosConfigurados));

			log.info("documentosConfigurados: " + documentosConfigurados);
			renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.LISTA_DOCUMENTOS,
					documentosConfigurados);

			registrarLog(tipoIdentificacion, identificacion, VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO, jsonObject, jsonObject, 200, 
					VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO, VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO, 
					renderRequest);
			
			log.info("AdjuntaRadicacion-pasoTransaccion: " + pasoTransaccion);
			if (httpReq.getSession().getAttribute("pasoTransaccion") != null) {
				pasoTransaccion = (String) httpReq.getSession(true).getAttribute("pasoTransaccion");

				if (!pasoTransaccion.equals("") && pasoTransaccion.equals("VEJEZ_PASO_3_ADJUNTA_DOCUMENTOS")) {
					this.viewTemplate = "/adjunta-documentos-radicacion-p1.jsp";
				} else if (!pasoTransaccion.equals("")
						&& pasoTransaccion.equals("VEJEZ_PASO_3_FIRMA_ELECTRONICA_RADICACION")) {
					this.viewTemplate = "/firma-electronica-radicacion.jsp";
				} else if (!pasoTransaccion.equals("")
						&& pasoTransaccion.equals("VEJEZ_PASO_3_ADJUNTA_DOCUMENTOS_RADICACION_VALIDACION")) {
					this.viewTemplate = "/adjunta-documentos-radicacion-p2.jsp";
				}
			}
		} else {
			this.viewTemplate = "/page-error.jsp";
			
			registrarLog(tipoIdentificacion, identificacion, VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO, jsonObject, jsonObject, 400, 
					VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO, VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO, 
					renderRequest);
		}

		super.doView(renderRequest, renderResponse);
	}

	private Boolean requiereFirmaElectronica(JSONArray documentosConfigurados) {
		Boolean requiere = false;
		for (int j = 0; j < documentosConfigurados.length(); j++) {
			JSONArray listaDocumentos = documentosConfigurados.getJSONObject(j).getJSONArray("listaDocumentos");
			if (documentosConfigurados.getJSONObject(j).getInt("idParentesco") == 1) {
				for (int i = 0; i < listaDocumentos.length(); i++) {
					if (listaDocumentos.getJSONObject(i).getBoolean("requiereFirmaElectronica")) {
						requiere = true;
						break;
					}
				}
				if (requiere)
					break;
			}
		}
		return requiere;
	}

	/**
	 * Metodo para validar si tiene documentos a cargar. SISISGO 24/09/2020
	 * 
	 * @param documentosConfigurados
	 * @return
	 */
	private Boolean requiereDocCargar(JSONArray documentosConfigurados) {
		Boolean requiere = false;
		for (int j = 0; j < documentosConfigurados.length(); j++) {
			JSONArray listaDocumentos = documentosConfigurados.getJSONObject(j).getJSONArray("listaDocumentos");
			if (documentosConfigurados.getJSONObject(j).getInt("idParentesco") == 1) {
				for (int i = 0; i < listaDocumentos.length(); i++) {
					if (!listaDocumentos.getJSONObject(i).getBoolean("requiereFirmaElectronica")) {
						requiere = true;
						break;
					}
				}
				if (requiere)
					break;
			}
		}
		return requiere;
	}

	private JSONArray getDocumentosConfigurados(JSONArray jsonArrayDocumentos, JSONArray jsonArrayBeneficiarios) {

		Map<String, JSONArray> mapaBeneficiarios = new HashMap<>();
		for (int i = 0; i < jsonArrayDocumentos.length(); i++) {
			String idBeneficiario = jsonArrayDocumentos.getJSONObject(i).getString("idBeneficiario");
			JSONArray jsonRespuesta = JSONFactoryUtil.createJSONArray();
			if (mapaBeneficiarios.containsKey(idBeneficiario)) {
				jsonRespuesta = mapaBeneficiarios.get(idBeneficiario);
			} else {
				mapaBeneficiarios.put(idBeneficiario, jsonRespuesta);
			}
			JSONObject jrChild = jsonArrayDocumentos.getJSONObject(i);

			int estadoDocumento = (int) jrChild.get("estadoDocumento");

			JSONObject documento = JSONFactoryUtil.createJSONObject();

			documento.put("documentoId", jrChild.get("documentoId"));
			documento.put("requiereFirmaElectronica", jrChild.get("requiereFirmaElectronica"));
			if (jrChild.has("nombreRechazoDocumento")) {
				documento.put("banderaRechazo", jrChild.get("nombreRechazoDocumento"));
			}
			switch (estadoDocumento) {
			case 1:
				/**
				 * Si el estado del documento es Este documento a�n no ha sido cargado se
				 * presentrar� el �cono y el bot�n Ver ejemplo y cargar frente a cada
				 * documento. Este documento no ha sido cargado - Ver ejemplo y cargar
				 */
				documento.put("estadoClase", "no-cargado" + " selected");
				documento.put("title", rb.getString("VJadjunta-documentos.title.ejemplo.cargar"));
				documento.put("boton", rb.getString("VJadjunta-documentos.botones.ver.ejemplo"));
				documento.put("botonClass", "carga");
				jsonRespuesta.put(documento);
				break;

			case 2:
				/**
				 * estadoDocumento == 2 Documento cargado - Ver el documento
				 */
				documento.put("estadoClase", "cargado");
				documento.put("title", rb.getString("VJadjunta-documentos.title.ver.documento"));
				documento.put("boton", rb.getString("VJadjunta-documentos.botones.ver"));
				documento.put("titleDelete", rb.getString("VJadjuntar-documentos.botones.eliminar"));
				documento.put("botonDelete", rb.getString("VJadjuntar-documentos.botones.eliminar"));
				documento.put("botonClass", "descarga");
				jsonRespuesta.put(documento);
				break;

			case 3:
				/**
				 * estadoDocumento == 3 El documento que cargaste no es el solicitado o es
				 * ilegible, c�rgalo nuevamente - Ver detalle y cargar
				 */
				documento.put("estadoClase", "docError");
				documento.put("title", rb.getString("VJadjunta-documentos.title.detalle.cargar"));
				documento.put("boton", rb.getString("VJadjunta-documentos.title.ver.detalle"));
				documento.put("banderaRechazo", jrChild.get("nombreRechazoDocumento"));
				documento.put("botonClass", "carga");
				jsonRespuesta.put(documento);

				break;

			case 4:
				/**
				 * estadoDocumento == 4 Documento verificado exitosamente - Ver el documento
				 */
				documento.put("estadoClase", "verificado");
				documento.put("title", rb.getString("VJadjunta-documentos.botones.ver.documento"));
				documento.put("boton", rb.getString("VJadjunta-documentos.botones.ver.documento"));
				documento.put("botonClass", "descarga");
				jsonRespuesta.put(documento);

				break;

			default:
				break;
			}

			/**
			 * Para los documentos Historia laboral oficial y Formulario de solicitud de
			 * Devoluci�n de saldo se incluir� el texto (Descargalo, f�rmalo, ponle tu
			 * huella y c�rgalo). Estos documentos tendr�n los botones Descargar y
			 * Cargar.
			 */
			/**
			 * Ajuste para Historia laboral oficial y Formulario de solicitud Ver el
			 * documento - Ver ejemplo y Carga -> Onbase Descarga (Formulario Solictud)->
			 * Jasper (la invocaci�n va directa) Descarga (Historia Laboral) -> Nuevo
			 * servicio para descarga de plantillas de historia
			 */
			if (!documento.has("banderaRechazo")) {
				documento.put("banderaRechazo", "SIN_RECHAZO");
			}

			String nombreDocumento = jrChild.getString("nombreDocumento");
			nombreDocumento = nombreDocumento.toLowerCase();
			nombreDocumento = nombreDocumento.substring(0, 1).toUpperCase() + nombreDocumento.substring(1);
			documento.put("nombreCorto", nombreDocumento);
			if (jrChild.getInt("documentoId") == 165 || jrChild.getInt("documentoId") == 236) {
				documento.put("nombreDocumento", nombreDocumento);

				documento.put("title1", rb.getString("VJadjunta-documentos.botones.descargar"));
				documento.put("boton1", rb.getString("VJadjunta-documentos.botones.descargar"));

			} else {
				documento.put("nombreDocumento", nombreDocumento);
			}

		}
		for (int j = 0; j < jsonArrayBeneficiarios.length(); j++) {
			JSONObject beneficiario = jsonArrayBeneficiarios.getJSONObject(j);
			String idBeneficiario = beneficiario.getString("beneficiarioId");
			beneficiario.put("listaDocumentos", mapaBeneficiarios.get(idBeneficiario));
			String nombreCompleto = "";
			nombreCompleto += Optional.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("primerNombre"))
					.orElse("");
			nombreCompleto += " " + Optional
					.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("segundoNombre")).orElse("");
			nombreCompleto += " " + Optional
					.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("primerApellido")).orElse("");
			nombreCompleto += " " + Optional
					.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("segundoApellido")).orElse("");
			beneficiario.put("nombreBeneficiario", nombreCompleto);
		}

		return jsonArrayBeneficiarios;
	}
	
	/**	<b>Nombre: </b> registrarLog </br>
	 * <b>Descripci�n:</b>  M�todo que registra el log de la aplicaci�n </br>
	 * <b>Fecha Creaci�n:</b> 21/12/2019 </br>
	 * <b>Autor:</b> HITSS  Andrea Daza </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * @param tipoIdentificacion
	 * @param identificacion
	 * @param servicio
	 * @param peticion
	 * @param respuesta
	 * @param codigo
	 * @param mensaje
	 * @param componente
	 * @param request
	 */
	private void registrarLog(String tipoIdentificacion, String identificacion, String servicio, JSONObject peticion,
			JSONObject respuesta,  int codigo, String mensaje, String componente, PortletRequest request) {

		// URl del servicio de log
		String urlLog = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionPortletKeys.LISTA_PROPIEDADES, RestClientApiConstant.URL_REST_LOGS);
		// URL del servicio de consumo
		
		try {
			Map<String, String> headers = rest.getHeaders(RestClientApiConstant.ZP, PortalUtil.getHttpServletRequest(request));
			JSONObject jsonHeader = JSONFactoryUtil.createJSONObject(headers.get(RestClientApiConstant.HEADER_RQU));
			String paginaURl = PortalUtil.getCurrentURL(request);
			JSONObject params = JSONFactoryUtil.createJSONObject();
			params.put(RestClientApiConstant.APLICATIVO, RestClientApiConstant.ZP);
			params.put(RestClientApiConstant.USUARIO_ID, identificacion);
			params.put(RestClientApiConstant.TIPO_ID_AFILIADO, tipoIdentificacion);
			params.put(RestClientApiConstant.NUMERO_IDENTIFICACION_AFILIADO, identificacion);
			params.put(RestClientApiConstant.NIT_EMPRESA, StringPool.BLANK);
			params.put(RestClientApiConstant.NOMBRE_PAGINA, VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO);
			params.put(RestClientApiConstant.URL_PAGINA, paginaURl.length() >= 500 ? paginaURl.substring(0,500) : paginaURl);
			params.put(RestClientApiConstant.COMPONENTE, componente);
			params.put(RestClientApiConstant.SESSION_ID, request.getPortletSession().getId());
			params.put(RestClientApiConstant.FECHA_EVENTO, new Date().getTime());
			params.put(RestClientApiConstant.IP_USUARIO, (String) jsonHeader.get(RestClientApiConstant.IP_ADDR));
			params.put(RestClientApiConstant.SERVICIO_CONSUMIDO, servicio);
			params.put(RestClientApiConstant.PARAMETROS_CONSUMO, peticion.toString());
			params.put(RestClientApiConstant.PARAMETROS_SALIDA, respuesta.toString());
			params.put(RestClientApiConstant.FECHA_CONSUMO_SERVICIO, new Date().getTime());
			params.put(RestClientApiConstant.FECHA_RESPUESTA_SERVICIO, new Date().getTime());			
			params.put(RestClientApiConstant.CODIGO_RETORNO, codigo);
			
			Map<String, String> headersLogs = new HashMap<>();
			headersLogs.put(RestClientApiConstant.CONTENT_TYPE, RestClientApiConstant.APPLICATION_JSON);
			
			rest.callRestServiceByPost(urlLog, params.toJSONString(), headersLogs, new LinkedHashMap<>());
		}catch (Exception e) {
			log.error(RestClientApiConstant.ERROR_GENERAL.concat(urlLog), e);
		}
	}

}