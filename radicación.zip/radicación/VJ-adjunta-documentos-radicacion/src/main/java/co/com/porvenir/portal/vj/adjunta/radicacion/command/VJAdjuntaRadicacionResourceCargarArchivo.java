package co.com.porvenir.portal.vj.adjunta.radicacion.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.cache.MultiVMPool;
import com.liferay.portal.kernel.cache.PortalCache;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.upload.FileItem;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.Base64;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.registry.Registry;
import com.liferay.registry.RegistryUtil;
import com.liferay.registry.ServiceReference;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Base64.Decoder;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.clientesws.rest.api.RestClientApiConstant;
import co.com.porvenir.portal.util.api.UtilApi;
import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"mvc.command.name="
				+ VJAdjuntaDocumentosRadicacionPortletKeys.RESOURCE_ADJUNTA_RADICACION_CARGAR }, service = MVCResourceCommand.class)
public class VJAdjuntaRadicacionResourceCargarArchivo extends BaseMVCResourceCommand {

	private static Log log = LogFactoryUtil.getLog(VJAdjuntaRadicacionResourceCargarArchivo.class);

	@Reference
	private VJAdjuntaDocumentosRadicacionApi adjuntaRadicacionServices;

	@Reference
	private UtilApi utilApi;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {

		log.info("resourceRequest VJAdjuntaRadicacion-ResourceCargarArchivo");
		JSONObject jsonResponse = JSONFactoryUtil.createJSONObject();
		try {

			UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(resourceRequest);
			Map<String, String[]> param = uploadRequest.getParameterMap();

			String idBeneficiario = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.ID_BENEFICIARIO)[0];
			String esPdf = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.ES_PDF)[0];
			String idDocumento = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.ID_DOCUMENTO)[0];

			JSONArray filesB64 = JSONFactoryUtil.createJSONArray();

			Map<String, FileItem[]> files = (Map<String, FileItem[]>) uploadRequest.getMultipartParameterMap();

			if (GetterUtil.getBoolean(resourceRequest.getPreferences().getValue(
					VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_ACTIVAR_ANTIVIRUS, StringPool.FALSE))) {
				log.debug("cargarArchivos() Antivirus Activo");
				String idVirus = files.keySet().stream()
						.filter(id -> !utilApi.checkApiDefenderFile(uploadRequest.getFile(id))).findFirst()
						.orElse(StringPool.BLANK);

				// String
				// idVirus=utilApi.checkApiDefenderFile(uploadRequest.getFile(files.keySet().));

				if (!idVirus.equals(StringPool.BLANK)) {
					throw new Exception(VJAdjuntaDocumentosRadicacionPortletKeys.ARCHIVO_SOSPECHOSO);
				}
			} else {
				log.debug("cargarArchivos() Antivirus Inactivo");
			}

			files.keySet().forEach(id -> {
				String f64 = StringPool.BLANK;
				try {
					f64 = Base64.encode(Files.readAllBytes(uploadRequest.getFile(id).toPath()));
				} catch (IOException e) {
					log.error("Error generar base 64 archivos");
					log.error(e);
				}
				filesB64.put(f64);
			});
			log.info("esPdf: " + esPdf);
			log.info("idDocumento: " + idDocumento);
			log.info("idBeneficiario: " + idBeneficiario);
			JSONObject respuesta = adjuntaRadicacionServices.cargarDocumento(resourceRequest,
					Boolean.parseBoolean(esPdf), idDocumento, idBeneficiario, filesB64);
			// convertir respueta a stream

			byte[] imgBytes = respuesta.toJSONString().getBytes();
			ByteArrayInputStream inStream = new ByteArrayInputStream(imgBytes);

			resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
			resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_JSON);
			PortletResponseUtil.sendFile(resourceRequest, resourceResponse, "", inStream);

		} catch (Exception e) {

			jsonResponse.put(VJAdjuntaDocumentosRadicacionPortletKeys.CODIGO,
					RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			log.error("Error en carga de documentos VJ-AdjuntaRadicacion");
			log.error(e.getMessage());
		}

	}

	MultiVMPool multiVMPool = getMultiVMPool();

	private MultiVMPool getMultiVMPool() {
		Registry registry = RegistryUtil.getRegistry();

		ServiceReference serviceReference = registry.getServiceReference(MultiVMPool.class);

		return (MultiVMPool) registry.getService(serviceReference);
	}

	private JSONObject cargarArchivos(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
		log.debug("Ingreso m�todo cargarArchivos()");
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		try {
			UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(resourceRequest);
			Map<String, String[]> param = uploadRequest.getParameterMap();

			String identificacion = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.IDENTIFICACION)[0];
			String tipoIdentificacion = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.TIPO_IDENTIFICACION)[0];
			String idBeneficiario = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.ID_BENEFICIARIO)[0];
			String isPdf = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.ES_PDF)[0];
			String idDoc = param.get(VJAdjuntaDocumentosRadicacionPortletKeys.ID_DOCUMENTO)[0];
			JSONArray filesB64 = JSONFactoryUtil.createJSONArray();

			Map<String, FileItem[]> files = (Map<String, FileItem[]>) uploadRequest.getMultipartParameterMap();

			if (GetterUtil.getBoolean(resourceRequest.getPreferences().getValue(
					VJAdjuntaDocumentosRadicacionPortletKeys.PREFERENCE_ACTIVAR_ANTIVIRUS, StringPool.FALSE))) {
				log.debug("cargarArchivos() Antivirus Activo");
				String idVirus = files.keySet().stream()
						.filter(id -> !utilApi.checkApiDefenderFile(uploadRequest.getFile(id))).findFirst()
						.orElse(StringPool.BLANK);

				// String
				// idVirus=utilApi.checkApiDefenderFile(uploadRequest.getFile(files.keySet().));

				if (!idVirus.equals(StringPool.BLANK)) {
					throw new Exception(VJAdjuntaDocumentosRadicacionPortletKeys.ARCHIVO_SOSPECHOSO);
				}
			} else {
				log.debug("cargarArchivos() Antivirus Inactivo");
			}

			files.keySet().forEach(id -> {
				String f64 = StringPool.BLANK;
				try {
					f64 = Base64.encode(Files.readAllBytes(uploadRequest.getFile(id).toPath()));
				} catch (IOException e) {
					e.printStackTrace();

				}
				filesB64.put(f64);
			});

			JSONObject request = JSONFactoryUtil.createJSONObject();
			request.put(VJAdjuntaDocumentosRadicacionPortletKeys.ID_BENEFICIARIO, Integer.parseInt(idBeneficiario));
			request.put(VJAdjuntaDocumentosRadicacionPortletKeys.ES_PDF, Boolean.parseBoolean(isPdf));
			request.put(VJAdjuntaDocumentosRadicacionPortletKeys.ID_DOCUMENTO, Integer.parseInt(idDoc));
			request.put(VJAdjuntaDocumentosRadicacionPortletKeys.ARCHIVOS_BASE_64, filesB64);
			log.info(filesB64);

			jsonObject = adjuntaRadicacionServices.cargarDocumento(resourceRequest, Boolean.parseBoolean(isPdf), idDoc,
					idBeneficiario, filesB64);
//			HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(resourceRequest));	
//			String jwt=getJwt(tipoIdentificacion, identificacion);
//			///////////consumo servicio
//			String  urlService = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionPortletKeys.LISTA_PROPIEDADES,
//					VJAdjuntaDocumentosRadicacionPortletKeys.URL_REST_VJ_CARGA_DOCUMENTAL_RADICACION);
//			
//			Map<String, String> headers = restApi.getHeaders(RestClientApiConstant.ZTA, httpReq);
//			headers.put(RestClientApiConstant.AUTHORIZATION, jwt);
//			
//			String url = dataListApi.getRecordValue(VJAdjuntaDocumentosRadicacionPortletKeys.LISTA_PROPIEDADES, RestClientApiConstant.URL_REST_LOGS);
//			
//			JSONObject params = restApi.createJSONParamLogs(RestClientApiConstant.ZP, url, identificacion, tipoIdentificacion, identificacion
//					, StringPool.BLANK,resourceRequest.getContextPath(), PortalUtil.getCurrentURL(resourceRequest).toString(),
//					VJAdjuntaDocumentosRadicacionPortletKeys.ACCION_CARGA_DOCUMENTO, resourceRequest.getPortletSession().getId());
//			log.debug("JWT m�todo cargarArchivos: " + jwt);
//			
//			log.debug("cargarArchivos() Request servicio de carga de archivos URL_CARGA_BASE64");
//			log.debug(request.toJSONString());
//			
//			log.debug("cargarArchivos() Invocando servicio URL_CARGA_BASE64");
//			
//			jsonObject = restApi.callRestServiceByPost(urlService, request.toJSONString(), headers,new LinkedHashMap<>(), params);
//			
			// JWT - carga de archivo
			if (jsonObject.has(VJAdjuntaDocumentosRadicacionPortletKeys.JWT)) {
				String jwtNuevo = jsonObject.getString(VJAdjuntaDocumentosRadicacionPortletKeys.JWT);
				PortalCache portalCache = multiVMPool
						.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
				portalCache.put(VJAdjuntaDocumentosRadicacionPortletKeys.JWT, jwtNuevo);
			}

			log.debug("cargarArchivos() Response servicio de carga de archivos URL_CARGA_BASE64");
			log.debug(jsonObject.toJSONString());

		} catch (Exception e) {
			log.error(e);
			if (e.getMessage().equals(VJAdjuntaDocumentosRadicacionPortletKeys.ARCHIVO_SOSPECHOSO)) {
				jsonObject.put(VJAdjuntaDocumentosRadicacionPortletKeys.CODIGO, RestClientApiConstant.SC_BAD_CONTENT);
			} else {
				jsonObject.put(VJAdjuntaDocumentosRadicacionPortletKeys.CODIGO,
						RestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}

		}
		return jsonObject;
	}

	/**
	 * POR11214, metodo para obtener el token
	 * 
	 * @param tipoIdentificacion
	 * @param identificacion
	 * @return
	 */
	private String getJwt(String tipoIdentificacion, String identificacion) {

		PortalCache portalCache = multiVMPool
				.getPortalCache(utilApi.getKeyUserCache(tipoIdentificacion, identificacion));
		Object jwt = portalCache.get(RestClientApiConstant.JWT);
		String jwtString = jwt != null ? jwt.toString() : StringPool.BLANK;
		jwtString = jwtString.indexOf(VJAdjuntaDocumentosRadicacionPortletKeys.BEARER) == -1
				? VJAdjuntaDocumentosRadicacionPortletKeys.BEARER + jwtString
				: jwtString;
		return jwtString;

	}

	private void reponseBase64(ResourceResponse resourceResponse, String base64) throws IOException, PortletException {
		OutputStream outStream = resourceResponse.getPortletOutputStream();
		Decoder dec = java.util.Base64.getDecoder();
		byte[] imgBytes = dec.decode(base64);
		ByteArrayInputStream inStream = new ByteArrayInputStream(imgBytes);

		byte[] buffer = new byte[1024];
		while (true) {
			int bytes = inStream.read(buffer);
			if (bytes <= 0) {
				break;
			}
			outStream.write(buffer, 0, bytes);
		}

		outStream.flush();
		outStream.close();
	}

}
