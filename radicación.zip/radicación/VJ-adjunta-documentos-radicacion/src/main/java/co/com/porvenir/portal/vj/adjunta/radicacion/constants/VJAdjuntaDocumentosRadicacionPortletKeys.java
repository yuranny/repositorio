package co.com.porvenir.portal.vj.adjunta.radicacion.constants;

/**
 * @author POR08185
 */
public class VJAdjuntaDocumentosRadicacionPortletKeys {
	
	public VJAdjuntaDocumentosRadicacionPortletKeys() {
		super();
	}

	public static final String VJAdjuntaDocumentosRadicacion = "VJAdjuntaDocumentosRadicacion";

	public static final String RESOURCE_ADJUNTA_RADICACION_DESCARGAR = "/vejez/adjunta-radicacion/descargar";
	public static final String RESOURCE_ADJUNTA_RADICACION_CARGAR = "/vejez/adjunta-radicacion/cargar";
	public static final String RESOURCE_ADJUNTA_RADICACION_ELIMINAR = "/vejez/adjunta-radicacion/eliminar";
	public static final String RESOURCE_ADJUNTA_RADICACION_GENERAR_JASPER = "/vejez/adjunta-radicacion/generar-jasper";
	public static final String RESOURCE_ADJUNTA_RADICACION_GUARDAR_P1 = "/vejez/adjunta-radicacion/guardar-p1";
	public static final String RESOURCE_ADJUNTA_RADICACION_VOLVER_P1 = "/vejez/adjunta-radicacion/volver-p1";
	public static final String RESOURCE_ADJUNTA_RADICACION_GUARDAR_P2 = "/vejez/adjunta-radicacion/guardar-p2";
	public static final String RESOURCE_ADJUNTA_RADICACION_VOLVER_P2 = "/vejez/adjunta-radicacion/volver-p2";
	public static final String RESOURCE_FIRMA_RADICACION_GENERAR_FIRMA = "/vejez/firma-radicacion/generar-firma";
	public static final String RESOURCE_FIRMA_RADICACION_VOLVER = "/vejez/firma-radicacion/volver";
	public static final String RESOURCE_ADJUNTA_RADICACION_P2 = "/vejez/adjunta-radicacion/view-p2";

	public static final String RENDER_ADJUNTA_RADICACION_P1 = "/vejez/adjunta-radicacion/view-p1";
	public static final String RENDER_FIRMA_RADICACION = "/vejez/firma-radicacion/view";

	/**
	 * tipo de beneficio
	 */
	public static final String TIPO = "tipo";
	public static final String TIPO_IDENTIFICACION = "tipoIdentificacion";
	public static final String IDENTIFICACION = "identificacion";
	public static final String CODIGO = "codigo";

	public static final String LISTA_DOCUMENTOS = "listaDocumentos";

	/**
	 * Carga de documentos
	 */
	public static final String ID_BENEFICIARIO = "idBeneficiario";
	public static final String ES_PDF = "documentoEsPdf";
	public static final String ID_DOCUMENTO = "idDocumento";
	public static final String NOMBRE_DOCUMENTO = "nombreDocumento";
	public static final String PREFERENCE_ACTIVAR_ANTIVIRUS = "PREFERENCE_ACTIVAR_ANTIVIRUS";
	public static final String ARCHIVOS_BASE_64 = "imagenesBase64";
	public static final String URL_CARGA_BASE64 = "URL_CARGA_BASE64";
	public static final String URL_REST_VJ_CARGA_DOCUMENTAL_RADICACION = "URL_REST_VJ_CARGA_DOCUMENTAL_RADICACION";
	public static final String ARCHIVO_SOSPECHOSO = "ARCHIVO_SOSPECHOSO";
	public static final String LISTA_PROPIEDADES = "ListaPropiedadesGlobalPrincipal";
	public static final String UTF_8 = "UTF-8";
	public static final String APPLICATION_JSON = "application/json";
	public static final String APPLICATION_PDF = "application/pdf";

	/**
	 * Tipos de beneficios de pension
	 */
	public static final String NO_DERECHO_PENSION_ANTICIPADA = "1";
	public static final String MESADA_ANTICIPADA = "2";
	public static final String MESADA_ANTICIPADA_EXCEDENTES = "3";
	public static final String MESADA_PENSIONAL = "4";
	public static final String MESADA_PENSIONAL_EXCEDENTES = "5";
	public static final String GARANTIA_PENSION_MINIMA = "6";
	public static final String DEVOLUCION_SALDOS = "7";
	public static final String NUEVA_MODALIDAD = "8";
	public static final String ESPERAR_RED_NORMAL_BONO = "9";
	public static final String ESPERAR_ACREDITACION_BONO = "10";
	public static final String COTIZACION_RENTA = "11";

	/**
	 * Preferencias
	 */
	public static final String PREFERENCE_URL_INGRESA = "URL_INGRESA";
	public static final String PREFERENCE_URL_HOME = "URL_HOME";
	public static final String PREFERENCE_URL_INFORMACION_PAGO = "URL_INFORMACION_PAGO";
	public static final String PREFERENCE_URL_ZP = "URL_ZP";
	public static final String PREFERENCE_DIAS_CONTINUIDAD = "DIAS_CONTINUIDAD";
	public static final String PREFERENCE_MONTO_FIRMA_ELECTRONICA = "MONTO_FIRMA_ELECTRONICA";
	public static final String PREFERENCE_LOGO_PORVENIR = "LOGO_PORVENIR";
	public static final String PREFERENCE_REPORTE_CONVENIOS_INTERNACIONALES = "REPORTE_CONVENIOS_INTERNACIONALES";
	public static final String PREFERENCE_REPORTE_FORMULARIO_DEVOLUCION_SALDOS = "REPORTE_FORMULARIO_DEVOLUCION_SALDOS";
	public static final String URL_FINALIZA_TRANSACCION = "URL_FINALIZA_TRANSACCION";
	public static final String URL_FIRMA_ELECTRONICA = "URL_FIRMA_ELECTRONICA";
	public static final String PESO_DOCUMENTOS = "pesoDocumentos";
	public static final String CANTIDAD_DOCUMENTOS = "cantidadDocumentos";
	public static final String IMAGEN_BUENA_CALIDAD = "imagenBuenaCalidad";
	public static final String IMAGEN_MALA_CALIDAD = "imagenMalaCalidad";
	public static final String INFOGRAFIA_HISTORIA = "urlInforgrafiaHistoria";
	public static final String DOCUMENTO_ID = "documentoId_";

	public static final String JSONARRAY_LISTA_BENEFICIARIOS = "listaBeneficiarios";

	/**
	 * Valor de Listas dinamicas LISTA_PARAMS de configuraci�n
	 */
	public static final String LIST_PARAMS = "ListParams";

	/**
	 * valor puede volver transaccion
	 */
	public static final String REGRESAR = "regresar";
	public static final String PUEDO_VISUALIZAR_HLO = "puedoVisualizarHlo";

	/**
	 * Total Intentos antes de irse a modal error servicio
	 */
	public static final String TOTALINTENTOS = "Total_Intentos";
	public static final String TOTAL_INTENTOS = "totalIntentos";
	public static final String CONT_SESION = "CONT_SESION";
	public static final String INCREMENTAR_COUNT = "incrementCountSesion";
	public static final String COUNT = "0";

	public static final String CARGAR_DATOS = "/vejez/adjunta-radicacion/cargar";
	public static final String DOCUMENTO = "documento";
	public static final String ACCION_CARGA_DOCUMENTO = "Adjunta documentos - cargarArchivos";
	public static final String JWT = "jwt";
	public static final String BEARER = "Bearer ";

	public static final String FIRMA_ELECTRONICA_JSP = "/firma-electronica-radicacion.jsp";
}