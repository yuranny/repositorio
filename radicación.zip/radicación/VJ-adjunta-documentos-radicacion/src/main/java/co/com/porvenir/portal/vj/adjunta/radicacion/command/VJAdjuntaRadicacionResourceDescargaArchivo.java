package co.com.porvenir.portal.vj.adjunta.radicacion.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Base64.Decoder;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"javax.portlet.name=VJAdjuntaDocumentosRadicacion", "mvc.command.name="
				+ VJAdjuntaDocumentosRadicacionPortletKeys.RESOURCE_ADJUNTA_RADICACION_DESCARGAR }, service = MVCResourceCommand.class)
public class VJAdjuntaRadicacionResourceDescargaArchivo extends BaseMVCResourceCommand {

	private static Log log = LogFactoryUtil.getLog(VJAdjuntaRadicacionResourceDescargaArchivo.class);

	@Reference
	private VJAdjuntaDocumentosRadicacionApi adjuntaRadicacionServices;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {
		log.error("resourceRequest VJAdjuntaRadicacion-ResourceDescargaArchivo");
		String idDocumento = resourceRequest.getParameter(VJAdjuntaDocumentosRadicacionPortletKeys.ID_DOCUMENTO);
		String idBeneficiario = ParamUtil.getString(resourceRequest,
				VJAdjuntaDocumentosRadicacionPortletKeys.ID_BENEFICIARIO, StringPool.BLANK);
		String pageAdjunta = resourceRequest.getParameter("pageAdjunta");
		String nombreDocumento = resourceRequest
				.getParameter(VJAdjuntaDocumentosRadicacionPortletKeys.NOMBRE_DOCUMENTO);

		String idDocSessionConcat = VJAdjuntaDocumentosRadicacionPortletKeys.DOCUMENTO_ID + idDocumento;
//		Validar si el documento esta session o necesita descargarse
//		if (resourceRequest.getPortletSession().getAttribute(idDocSessionConcat) != null
//				&& resourceRequest.getPortletSession().getAttribute(idDocSessionConcat).equals(StringPool.BLANK)) {
//			String contenidoDocSession = (String) resourceRequest.getPortletSession().getAttribute(idDocSessionConcat);
//			resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
//			resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_PDF);
//			PortletResponseUtil.sendFile(resourceRequest, resourceResponse, nombreDocumento + ".pdf",
//					base64ToOutputStream(contenidoDocSession));
//		} else

		if (pageAdjunta.equals("adjunta1")) {
			resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
			resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_PDF);

			PortletResponseUtil.sendFile(resourceRequest, resourceResponse, nombreDocumento + ".pdf",
					adjuntaRadicacionServices.descargarDocumento(resourceRequest, idDocumento, idBeneficiario));

		} else {
			if (adjuntaRadicacionServices.descargaDocumentoOnBase(resourceRequest, idDocumento,
					idBeneficiario) != null) {
				log.error("Descargar de onBase");
				resourceResponse.setCharacterEncoding(VJAdjuntaDocumentosRadicacionPortletKeys.UTF_8);
				resourceResponse.setContentType(VJAdjuntaDocumentosRadicacionPortletKeys.APPLICATION_PDF);
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, nombreDocumento + ".pdf",
						adjuntaRadicacionServices.descargaDocumentoOnBase(resourceRequest, idDocumento,
								idBeneficiario));
			} else {
				log.error("No descargar de onBase");
				include(resourceRequest, resourceResponse, "/no-hay-pdf.jsp");
			}
		}
	}

	private InputStream base64ToOutputStream(String base64) {
		Decoder dec = java.util.Base64.getDecoder();
		byte[] imgBytes = dec.decode(base64);
		return new ByteArrayInputStream(imgBytes);
	}

}
