package co.com.porvenir.portal.vj.adjunta.radicacion.command;

import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import co.com.porvenir.portal.vj.adjunta.api.api.VJAdjuntaDocumentosRadicacionApi;
import co.com.porvenir.portal.vj.adjunta.radicacion.constants.VJAdjuntaDocumentosRadicacionPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + VJAdjuntaDocumentosRadicacionPortletKeys.VJAdjuntaDocumentosRadicacion,
		"mvc.command.name="
				+ VJAdjuntaDocumentosRadicacionPortletKeys.RENDER_FIRMA_RADICACION }, service = MVCRenderCommand.class)
public class VJAadjuntaRadicacionRenderFirma implements MVCRenderCommand {

	private static Log log = LogFactoryUtil.getLog(VJadjuntaRadicacionRenderPagAdjuntaP2.class);

	private static ResourceBundle rb = ResourceBundle.getBundle("content.Language");

	@Reference
	private VJAdjuntaDocumentosRadicacionApi adjuntaRadicacionService;

	@Reference
	private DinamicDatalistApi dataListApi;

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		HttpServletRequest httpReq = PortalUtil
				.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest));

		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.TIPO, adjuntaRadicacionService
				.inicializaParametro(renderRequest, VJAdjuntaDocumentosRadicacionPortletKeys.TIPO));
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.TIPO_IDENTIFICACION,
				adjuntaRadicacionService.inicializaParametro(renderRequest,
						VJAdjuntaDocumentosRadicacionPortletKeys.TIPO_IDENTIFICACION));
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.IDENTIFICACION, adjuntaRadicacionService
				.inicializaParametro(renderRequest, VJAdjuntaDocumentosRadicacionPortletKeys.IDENTIFICACION));
		JSONObject documents = adjuntaRadicacionService.consultarListaDocumentos(renderRequest);
		int codeResponse = documents.getInt(VJAdjuntaDocumentosRadicacionPortletKeys.CODIGO);
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CODIGO, codeResponse);

		JSONObject listParams = dataListApi.getServiceValue(VJAdjuntaDocumentosRadicacionPortletKeys.LIST_PARAMS,
				VJAdjuntaDocumentosRadicacionPortletKeys.TOTALINTENTOS);
		String totalIntentos = listParams.getString("url");
		renderRequest.setAttribute("totalIntentos", totalIntentos);

		String countSesion = VJAdjuntaDocumentosRadicacionPortletKeys.COUNT;
		if (httpReq.getSession().getAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION) != null) {
			countSesion = (String) httpReq.getSession()
					.getAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION);
		}
		renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.CONT_SESION, countSesion);

		if (codeResponse == 200) {
			JSONArray documentosConfigurados = getDocumentosConfigurados(
					documents.getJSONArray(VJAdjuntaDocumentosRadicacionPortletKeys.LISTA_DOCUMENTOS),
					documents.getJSONArray(VJAdjuntaDocumentosRadicacionPortletKeys.JSONARRAY_LISTA_BENEFICIARIOS));
			renderRequest.setAttribute(VJAdjuntaDocumentosRadicacionPortletKeys.LISTA_DOCUMENTOS,
					documentosConfigurados);
		}

		return VJAdjuntaDocumentosRadicacionPortletKeys.FIRMA_ELECTRONICA_JSP;

	}

	private JSONArray getDocumentosConfigurados(JSONArray jsonArrayDocumentos, JSONArray jsonArrayBeneficiarios) {

		Map<String, JSONArray> mapaBeneficiarios = new HashMap<>();
		for (int i = 0; i < jsonArrayDocumentos.length(); i++) {
			String idBeneficiario = jsonArrayDocumentos.getJSONObject(i).getString("idBeneficiario");
			JSONArray jsonRespuesta = JSONFactoryUtil.createJSONArray();
			if (mapaBeneficiarios.containsKey(idBeneficiario)) {
				jsonRespuesta = mapaBeneficiarios.get(idBeneficiario);
			} else {
				mapaBeneficiarios.put(idBeneficiario, jsonRespuesta);
			}
			JSONObject jrChild = jsonArrayDocumentos.getJSONObject(i);

			int estadoDocumento = (int) jrChild.get("estadoDocumento");

			JSONObject documento = JSONFactoryUtil.createJSONObject();

			documento.put("documentoId", jrChild.get("documentoId"));
			documento.put("requiereFirmaElectronica", jrChild.get("requiereFirmaElectronica"));
			if (jrChild.has("nombreRechazoDocumento")) {
				documento.put("banderaRechazo", jrChild.get("nombreRechazoDocumento"));
			}
			switch (estadoDocumento) {
			case 1:
				/**
				 * Si el estado del documento es Este documento a�n no ha sido cargado se
				 * presentrar� el �cono y el bot�n Ver ejemplo y cargar frente a cada
				 * documento. Este documento no ha sido cargado - Ver ejemplo y cargar
				 */
				documento.put("estadoClase", "no-cargado" + " selected");
				documento.put("title", rb.getString("VJadjunta-documentos.title.ejemplo.cargar"));
				documento.put("boton", rb.getString("VJadjunta-documentos.botones.ver.ejemplo"));
				documento.put("botonClass", "carga");
				jsonRespuesta.put(documento);
				break;

			case 2:
				/**
				 * estadoDocumento == 2 Documento cargado - Ver el documento
				 */
				documento.put("estadoClase", "cargado");
				documento.put("title", rb.getString("VJadjunta-documentos.title.ver.documento"));
				documento.put("boton", rb.getString("VJadjunta-documentos.botones.ver"));
				documento.put("titleDelete", rb.getString("VJadjuntar-documentos.botones.eliminar"));
				documento.put("botonDelete", rb.getString("VJadjuntar-documentos.botones.eliminar"));
				documento.put("botonClass", "descarga");
				jsonRespuesta.put(documento);
				break;

			case 3:
				/**
				 * estadoDocumento == 3 El documento que cargaste no es el solicitado o es
				 * ilegible, c�rgalo nuevamente - Ver detalle y cargar
				 */
				documento.put("estadoClase", "docError");
				documento.put("title", rb.getString("VJadjunta-documentos.title.detalle.cargar"));
				documento.put("boton", rb.getString("VJadjunta-documentos.title.ver.detalle"));
				documento.put("banderaRechazo", jrChild.get("nombreRechazoDocumento"));
				documento.put("botonClass", "carga");
				jsonRespuesta.put(documento);

				break;

			case 4:
				/**
				 * estadoDocumento == 4 Documento verificado exitosamente - Ver el documento
				 */
				documento.put("estadoClase", "verificado");
				documento.put("title", rb.getString("VJadjunta-documentos.botones.ver.documento"));
				documento.put("boton", rb.getString("VJadjunta-documentos.botones.ver.documento"));
				documento.put("botonClass", "descarga");
				jsonRespuesta.put(documento);

				break;

			default:
				break;
			}

			/**
			 * Para los documentos Historia laboral oficial y Formulario de solicitud de
			 * Devoluci�n de saldo se incluir� el texto (Descargalo, f�rmalo, ponle tu
			 * huella y c�rgalo). Estos documentos tendr�n los botones Descargar y
			 * Cargar.
			 */
			/**
			 * Ajuste para Historia laboral oficial y Formulario de solicitud Ver el
			 * documento - Ver ejemplo y Carga -> Onbase Descarga (Formulario Solictud)->
			 * Jasper (la invocaci�n va directa) Descarga (Historia Laboral) -> Nuevo
			 * servicio para descarga de plantillas de historia
			 */
			if (!documento.has("banderaRechazo")) {
				documento.put("banderaRechazo", "SIN_RECHAZO");
			}

			String nombreDocumento = jrChild.getString("nombreDocumento");
			nombreDocumento = nombreDocumento.toLowerCase();
			nombreDocumento = nombreDocumento.substring(0, 1).toUpperCase() + nombreDocumento.substring(1);
			documento.put("nombreCorto", nombreDocumento);
			if (jrChild.getInt("documentoId") == 165 || jrChild.getInt("documentoId") == 236) {
				documento.put("nombreDocumento", nombreDocumento);

				documento.put("title1", rb.getString("VJadjunta-documentos.botones.descargar"));
				documento.put("boton1", rb.getString("VJadjunta-documentos.botones.descargar"));

			} else {
				documento.put("nombreDocumento", nombreDocumento);
			}

		}
		for (int j = 0; j < jsonArrayBeneficiarios.length(); j++) {
			JSONObject beneficiario = jsonArrayBeneficiarios.getJSONObject(j);
			String idBeneficiario = beneficiario.getString("beneficiarioId");
			beneficiario.put("listaDocumentos", mapaBeneficiarios.get(idBeneficiario));
			String nombreCompleto = "";
			nombreCompleto += Optional.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("primerNombre"))
					.orElse("");
			nombreCompleto += " " + Optional
					.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("segundoNombre")).orElse("");
			nombreCompleto += " " + Optional
					.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("primerApellido")).orElse("");
			nombreCompleto += " " + Optional
					.ofNullable(jsonArrayBeneficiarios.getJSONObject(j).getString("segundoApellido")).orElse("");
			beneficiario.put("nombreBeneficiario", nombreCompleto);
		}
		log.info("json respuesta: " + jsonArrayBeneficiarios);
		return jsonArrayBeneficiarios;
	}

}
